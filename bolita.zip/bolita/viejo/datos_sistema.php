<?php
// datos_sistema.php
require_once 'db_connection_avanzado.php';

function obtenerDatosSistema() {
    $datos = [
        'tiradas' => obtenerUltimasTiradas(10),
        'patrones' => [
            'completo' => obtenerPatrones('completo', 10),
            'parcial' => obtenerPatrones('parcial', 10),
            'suma' => obtenerPatrones('suma', 10),
            'paridad' => obtenerPatrones('paridad', 10),
            'repeticion' => obtenerPatrones('repeticion', 10)
        ],
        'estadisticas' => [
            'frecuencia_digitos' => obtenerEstadisticas('frecuencia_digito'),
            'paridad' => [
                'pares' => obtenerEstadisticas('frecuencia_pares'),
                'impares' => obtenerEstadisticas('frecuencia_impares')
            ],
            'promedio' => obtenerEstadisticas('promedio')
        ],
        'predicciones' => obtenerUltimasPredicciones(10),
        'efectividad' => obtenerEfectividadPredicciones()
    ];

    return $datos;
}

function obtenerUltimasTiradas($limit) {
    global $conn;
    $sql = "SELECT * FROM tiradas ORDER BY fecha DESC, hora DESC LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function obtenerUltimasPredicciones($limit) {
    global $conn;
    $sql = "SELECT * FROM predicciones ORDER BY fecha_prediccion DESC LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Asumiendo que ya tienes las funciones obtenerPatrones, obtenerEstadisticas y obtenerEfectividadPredicciones definidas en db_connection_avanzado.php

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: application/json');
    echo json_encode(obtenerDatosSistema());
}
?>