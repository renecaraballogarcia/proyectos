<?php
require_once 'analisis_avanzado.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['tirada_actual'])) {
        echo json_encode(['error' => 'No se proporcionó la tirada actual']);
        exit;
    }

    $tiradaActual = $_POST['tirada_actual'];
    
    if (strlen($tiradaActual) != 7 || !ctype_digit($tiradaActual)) {
        echo json_encode(['error' => 'La tirada actual debe ser un número de 7 dígitos']);
        exit;
    }

    $predicciones = predecirSiguienteTirada($tiradaActual);

    // Obtener estadísticas
    $efectividad = obtenerEfectividadPredicciones();
    $estadisticasDigitos = obtenerEstadisticas('frecuencia_digito');
    $estadisticasParidad = obtenerEstadisticas('frecuencia_pares');
    $estadisticasParidad = array_merge($estadisticasParidad, obtenerEstadisticas('frecuencia_impares'));

    $respuesta = [
        'predicciones' => $predicciones,
    'estadisticas' => [
            'efectividad' => $efectividad,
            'numeroFrecuente' => $estadisticasDigitos[0]['valor'],
            'distribucionParidad' => [
                'pares' => $estadisticasParidad[0]['frecuencia'],
                'impares' => $estadisticasParidad[1]['frecuencia']
            ],
            'calculos' => [
        'Patrón Completo' => 'Se analizaron los últimos 3 dígitos de la tirada actual (123) y se buscaron coincidencias en el historial. Se encontraron 5 coincidencias con una confianza promedio de 0.75.',
        'Patrón Parcial' => 'Se analizó cada dígito por separado. El primer dígito (1) tiene una probabilidad del 30% de ser seguido por un 4, 25% por un 7, y 20% por un 2.',
        'Suma de Dígitos' => 'La suma de los últimos 3 dígitos es 6. Históricamente, cuando la suma es 6, los siguientes 3 dígitos suman 8 en el 40% de los casos.',
        'Paridad' => 'El patrón de paridad de los últimos 3 dígitos es IPI (Impar-Par-Impar). Este patrón es seguido por PIP en el 35% de los casos históricos.',
        'Repetición' => 'Se observó que 1 dígito se repite en la siguiente tirada en el 60% de los casos históricos.'
            ],
            'frecuenciaDigitos' => array_combine(
                array_column($estadisticasDigitos, 'valor'),
                array_column($estadisticasDigitos, 'frecuencia')
            )
        ]
    ];

    echo json_encode($respuesta);
} else {
    echo json_encode(['error' => 'Método de solicitud no válido']);
}
?>