-- Create the database
CREATE DATABASE IF NOT EXISTS loteria_cubana_avanzada;
USE loteria_cubana_avanzada;

-- Create the tiradas table
CREATE TABLE IF NOT EXISTS tiradas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    hora TIME NOT NULL,
    tirada VARCHAR(7) NOT NULL,
    tirada_siguiente VARCHAR(7) NOT NULL,
    fecha_siguiente DATE NOT NULL,
    hora_siguiente TIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the patrones table
CREATE TABLE IF NOT EXISTS patrones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('completo', 'parcial', 'suma', 'paridad', 'repeticion') NOT NULL,
    patron VARCHAR(20) NOT NULL,
    frecuencia INT NOT NULL DEFAULT 1,
    efectividad FLOAT NOT NULL DEFAULT 0,
    ultima_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY tipo_patron (tipo, patron)
);

-- Create the estadisticas table
CREATE TABLE IF NOT EXISTS estadisticas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(50) NOT NULL,
    valor VARCHAR(20) NOT NULL,
    frecuencia INT NOT NULL DEFAULT 0,
    ultima_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY tipo_valor (tipo, valor)
);

-- Create the predicciones table
CREATE TABLE IF NOT EXISTS predicciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha_prediccion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    tirada_base VARCHAR(7) NOT NULL,
    prediccion VARCHAR(3) NOT NULL,
    confianza FLOAT NOT NULL,
    resultado VARCHAR(3),
    acertado BOOLEAN,
    INDEX idx_tirada_base (tirada_base),
    INDEX idx_fecha_prediccion (fecha_prediccion)
);

-- Create indexes for better performance
CREATE INDEX idx_tiradas_fecha_hora ON tiradas (fecha, hora);