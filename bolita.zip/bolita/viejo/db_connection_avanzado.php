<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loteria_cubana_avanzada";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

function insertarTirada($fecha, $hora, $tirada, $tirada_siguiente, $fecha_siguiente, $hora_siguiente) {
    global $conn;
    $sql = "INSERT INTO tiradas (fecha, hora, tirada, tirada_siguiente, fecha_siguiente, hora_siguiente) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $fecha, $hora, $tirada, $tirada_siguiente, $fecha_siguiente, $hora_siguiente);
    $stmt->execute();
    $stmt->close();
}

function obtenerTiradas($limit = 1000) {
    global $conn;
    $sql = "SELECT * FROM tiradas ORDER BY fecha DESC, hora DESC LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function actualizarPatron($tipo, $patron, $frecuencia, $efectividad) {
    global $conn;
    $sql = "INSERT INTO patrones (tipo, patron, frecuencia, efectividad, ultima_actualizacion) 
            VALUES (?, ?, ?, ?, NOW()) 
            ON DUPLICATE KEY UPDATE 
            frecuencia = frecuencia + ?, efectividad = ?, ultima_actualizacion = NOW()";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssiddi", $tipo, $patron, $frecuencia, $efectividad, $frecuencia, $efectividad);
    $stmt->execute();
    $stmt->close();
}

function obtenerPatrones($tipo, $limit = 100) {
    global $conn;
    $sql = "SELECT * FROM patrones WHERE tipo = ? ORDER BY efectividad DESC, frecuencia DESC LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $tipo, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function actualizarEstadistica($tipo, $valor, $frecuencia) {
    global $conn;
    $sql = "INSERT INTO estadisticas (tipo, valor, frecuencia, ultima_actualizacion) 
            VALUES (?, ?, ?, NOW()) 
            ON DUPLICATE KEY UPDATE 
            frecuencia = frecuencia + ?, ultima_actualizacion = NOW()";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssii", $tipo, $valor, $frecuencia, $frecuencia);
    $stmt->execute();
    $stmt->close();
}

function obtenerEstadisticas($tipo, $limit = 100) {
    global $conn;
    $sql = "SELECT * FROM estadisticas WHERE tipo = ? ORDER BY frecuencia DESC LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $tipo, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function insertarPrediccion($tirada_base, $prediccion, $confianza) {
    global $conn;
    $sql = "INSERT INTO predicciones (fecha_prediccion, tirada_base, prediccion, confianza) 
            VALUES (NOW(), ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssd", $tirada_base, $prediccion, $confianza);
    $stmt->execute();
    $stmt->close();
}

function actualizarResultadoPrediccion($tirada_base, $resultado) {
    global $conn;
    $sql = "UPDATE predicciones SET resultado = ?, acertado = (prediccion = ?) 
            WHERE tirada_base = ? AND resultado IS NULL 
            ORDER BY fecha_prediccion DESC LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $resultado, $resultado, $tirada_base);
    $stmt->execute();
    $stmt->close();
}

function obtenerEfectividadPredicciones() {
    global $conn;
    $sql = "SELECT COUNT(*) as total, SUM(acertado) as aciertos FROM predicciones WHERE resultado IS NOT NULL";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['total'] > 0 ? ($row['aciertos'] / $row['total']) : 0;
}
?>