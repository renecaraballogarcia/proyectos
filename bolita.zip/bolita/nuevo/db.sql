-- Crear la base de datos si no existe
CREATE DATABASE IF NOT EXISTS loteria_cubana_avanzada;

-- Usar la base de datos
USE loteria_cubana_avanzada;

-- Tabla de tiradas
CREATE TABLE IF NOT EXISTS tiradas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    hora TIME NOT NULL,
    tirada VARCHAR(7) NOT NULL,
    tirada_siguiente VARCHAR(7) NOT NULL,
    fecha_siguiente DATE NOT NULL,
    hora_siguiente TIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de patrones
CREATE TABLE IF NOT EXISTS patrones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('completo', 'parcial', 'suma', 'paridad', 'repeticion') NOT NULL,
    patron VARCHAR(20) NOT NULL,
    frecuencia INT NOT NULL DEFAULT 1,
    efectividad FLOAT NOT NULL DEFAULT 0,
    ultima_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY tipo_patron (tipo, patron)
);

-- Tabla de estadísticas
CREATE TABLE IF NOT EXISTS estadisticas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(50) NOT NULL,
    valor VARCHAR(20) NOT NULL,
    frecuencia INT NOT NULL DEFAULT 0,
    ultima_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY tipo_valor (tipo, valor)
);

-- Tabla de predicciones
CREATE TABLE IF NOT EXISTS predicciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha_prediccion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    tirada_base VARCHAR(7) NOT NULL,
    predicciones TEXT NOT NULL,
    resultado_real VARCHAR(3),
    acertado BOOLEAN,
    tipo ENUM('completo', 'parcial', 'suma', 'paridad', 'repeticion') NOT NULL
);

-- Índices para mejorar el rendimiento
CREATE INDEX idx_tiradas_fecha_hora ON tiradas (fecha, hora);
CREATE INDEX idx_predicciones_fecha ON predicciones (fecha_prediccion);
CREATE INDEX idx_predicciones_tirada_base ON predicciones (tirada_base);