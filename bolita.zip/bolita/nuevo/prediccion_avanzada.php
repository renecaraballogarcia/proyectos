<?php
require_once 'analisis_avanzado.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['tirada_actual'])) {
        echo json_encode(['error' => 'No se proporcionó la tirada actual']);
        exit;
    }

    $tiradaActual = $_POST['tirada_actual'];
    
    if (strlen($tiradaActual) != 7 || !ctype_digit($tiradaActual)) {
        echo json_encode(['error' => 'La tirada actual debe ser un número de 7 dígitos']);
        exit;
    }

    $predicciones = predecirSiguienteTirada($tiradaActual);

    $efectividad = obtenerTasaExito();
    $estadisticasDigitos = obtenerEstadisticas('frecuencia_digito');
    $estadisticasParidad = obtenerEstadisticas('frecuencia_pares');
    $estadisticasParidad = array_merge($estadisticasParidad, obtenerEstadisticas('frecuencia_impares'));

    $respuesta = [
        'predicciones' => $predicciones,
        'estadisticas' => [
            'efectividad' => $efectividad,
            'numeroFrecuente' => $estadisticasDigitos[0]['valor'],
            'distribucionParidad' => [
                'pares' => $estadisticasParidad[0]['frecuencia'],
                'impares' => $estadisticasParidad[1]['frecuencia']
            ],
            'calculos' => [
                'Patrón Completo' => 'Se analizaron los últimos 3 dígitos de la tirada actual (' . substr($tiradaActual, -3) . ') y se buscaron coincidencias en el historial.',
                'Patrón Parcial' => 'Se analizó cada dígito por separado de los últimos 3 dígitos.',
                'Suma de Dígitos' => 'La suma de los últimos 3 dígitos es ' . array_sum(str_split(substr($tiradaActual, -3))) . '.',
                'Paridad' => 'El patrón de paridad de los últimos 3 dígitos es ' . implode('', array_map(function($n) { return $n % 2 ? 'I' : 'P'; }, str_split(substr($tiradaActual, -3)))) . '.',
                'Repetición' => 'Se analizó la cantidad de dígitos que se repiten entre la tirada actual y las predicciones.'
            ],
            'frecuenciaDigitos' => array_combine(
                array_column($estadisticasDigitos, 'valor'),
                array_column($estadisticasDigitos, 'frecuencia')
            )
        ]
    ];

    echo json_encode($respuesta);
} else {
    echo json_encode(['error' => 'Método de solicitud no válido']);
}
?>
