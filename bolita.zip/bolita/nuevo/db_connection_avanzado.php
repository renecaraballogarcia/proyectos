<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loteria_cubana_avanzada";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

function insertarTirada($fecha, $hora, $tirada, $tirada_siguiente, $fecha_siguiente, $hora_siguiente) {
    global $conn;
    $sql = "INSERT INTO tiradas (fecha, hora, tirada, tirada_siguiente, fecha_siguiente, hora_siguiente) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $fecha, $hora, $tirada, $tirada_siguiente, $fecha_siguiente, $hora_siguiente);
    $stmt->execute();
    $stmt->close();
}

function obtenerTiradas($limit = 1000) {
    global $conn;
    $sql = "SELECT * FROM tiradas ORDER BY fecha DESC, hora DESC LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function actualizarPatron($tipo, $patron, $frecuencia, $efectividad) {
    global $conn;
    $sql = "INSERT INTO patrones (tipo, patron, frecuencia, efectividad) 
            VALUES (?, ?, ?, ?) 
            ON DUPLICATE KEY UPDATE 
            frecuencia = frecuencia + ?, efectividad = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssiddi", $tipo, $patron, $frecuencia, $efectividad, $frecuencia, $efectividad);
    $stmt->execute();
    $stmt->close();
}

function obtenerPatrones($tipo, $limit = 100) {
    global $conn;
    $sql = "SELECT * FROM patrones WHERE tipo = ? ORDER BY efectividad DESC, frecuencia DESC LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $tipo, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function actualizarEstadistica($tipo, $valor, $frecuencia) {
    global $conn;
    $sql = "INSERT INTO estadisticas (tipo, valor, frecuencia) 
            VALUES (?, ?, ?) 
            ON DUPLICATE KEY UPDATE 
            frecuencia = frecuencia + ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssii", $tipo, $valor, $frecuencia, $frecuencia);
    $stmt->execute();
    $stmt->close();
}

function obtenerEstadisticas($tipo, $limit = 100) {
    global $conn;
    $sql = "SELECT * FROM estadisticas WHERE tipo = ? ORDER BY frecuencia DESC LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $tipo, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function insertarPrediccion($tirada_base, $predicciones, $tipo) {
    global $conn;
    $predicciones_json = json_encode($predicciones);
    $sql = "INSERT INTO predicciones (tirada_base, predicciones, tipo) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $tirada_base, $predicciones_json, $tipo);
    $stmt->execute();
    $stmt->close();
}

function actualizarResultadoPrediccion($tirada_base, $resultado_real) {
    global $conn;
    $sql = "UPDATE predicciones SET resultado_real = ?, acertado = JSON_CONTAINS(predicciones, ?, '$.predicciones[*].prediccion') 
            WHERE tirada_base = ? AND resultado_real IS NULL 
            ORDER BY fecha_prediccion DESC LIMIT 1";
    $stmt = $conn->prepare($sql);
    $resultado_json = json_encode($resultado_real);
    $stmt->bind_param("sss", $resultado_real, $resultado_json, $tirada_base);
    $stmt->execute();
    $stmt->close();
}

function obtenerTasaExito() {
    global $conn;
    $sql = "SELECT 
                COUNT(*) as total_predicciones,
                SUM(acertado) as predicciones_acertadas
            FROM predicciones
            WHERE resultado_real IS NOT NULL";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    
    if ($row['total_predicciones'] > 0) {
        return ($row['predicciones_acertadas'] / $row['total_predicciones']) * 100;
    }
    return 0;
}

function obtenerMejorMetodo() {
    global $conn;
    $sql = "SELECT 
                tipo,
                COUNT(*) as total_predicciones,
                SUM(acertado) as predicciones_acertadas,
                (SUM(acertado) / COUNT(*)) * 100 as tasa_exito
            FROM predicciones
            WHERE resultado_real IS NOT NULL
            GROUP BY tipo
            HAVING tasa_exito >= 80
            ORDER BY tasa_exito DESC
            LIMIT 1";
    $result = $conn->query($sql);
    return $result->fetch_assoc();
}
?>