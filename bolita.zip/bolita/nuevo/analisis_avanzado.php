<?php
require_once 'db_connection_avanzado.php';

function analizarPatrones() {
    $tiradas = obtenerTiradas();
    $patrones = [];

    foreach ($tiradas as $tirada) {
        analizarPatronCompleto($tirada, $patrones);
        analizarPatronParcial($tirada, $patrones);
        analizarPatronSuma($tirada, $patrones);
        analizarPatronParidad($tirada, $patrones);
        analizarPatronRepeticion($tirada, $patrones);
    }

    foreach ($patrones as $tipo => $patronesTipo) {
        foreach ($patronesTipo as $patron => $datos) {
            actualizarPatron($tipo, $patron, $datos['frecuencia'], $datos['efectividad']);
        }
    }

    actualizarEstadisticasGenerales($tiradas);
}

function analizarPatronCompleto($tirada, &$patrones) {
    $ultimosTresDigitos = substr($tirada['tirada'], -3);
    $primerosTresDigitosSiguiente = substr($tirada['tirada_siguiente'], 0, 3);
    
    $patron = $ultimosTresDigitos . '-' . $primerosTresDigitosSiguiente;
    
    if (!isset($patrones['completo'][$patron])) {
        $patrones['completo'][$patron] = ['frecuencia' => 1, 'efectividad' => 1];
    } else {
        $patrones['completo'][$patron]['frecuencia']++;
        $patrones['completo'][$patron]['efectividad'] = 
            ($patrones['completo'][$patron]['efectividad'] * ($patrones['completo'][$patron]['frecuencia'] - 1) + 1) / 
            $patrones['completo'][$patron]['frecuencia'];
    }
}

function analizarPatronParcial($tirada, &$patrones) {
    $ultimosTresDigitos = str_split(substr($tirada['tirada'], -3));
    $primerosTresDigitosSiguiente = str_split(substr($tirada['tirada_siguiente'], 0, 3));
    
    for ($i = 0; $i < 3; $i++) {
        $patron = $ultimosTresDigitos[$i] . '-' . $primerosTresDigitosSiguiente[$i];
        
        if (!isset($patrones['parcial'][$patron])) {
            $patrones['parcial'][$patron] = ['frecuencia' => 1, 'efectividad' => 1];
        } else {
            $patrones['parcial'][$patron]['frecuencia']++;
            $patrones['parcial'][$patron]['efectividad'] = 
                ($patrones['parcial'][$patron]['efectividad'] * ($patrones['parcial'][$patron]['frecuencia'] - 1) + 1) / 
                $patrones['parcial'][$patron]['frecuencia'];
        }
    }
}

function analizarPatronSuma($tirada, &$patrones) {
    $ultimosTresDigitos = array_sum(str_split(substr($tirada['tirada'], -3)));
    $primerosTresDigitosSiguiente = array_sum(str_split(substr($tirada['tirada_siguiente'], 0, 3)));
    
    $patron = $ultimosTresDigitos . '-' . $primerosTresDigitosSiguiente;
    
    if (!isset($patrones['suma'][$patron])) {
        $patrones['suma'][$patron] = ['frecuencia' => 1, 'efectividad' => 1];
    } else {
        $patrones['suma'][$patron]['frecuencia']++;
        $patrones['suma'][$patron]['efectividad'] = 
            ($patrones['suma'][$patron]['efectividad'] * ($patrones['suma'][$patron]['frecuencia'] - 1) + 1) / 
            $patrones['suma'][$patron]['frecuencia'];
    }
}

function analizarPatronParidad($tirada, &$patrones) {
    $ultimosTresDigitos = array_map('intval', str_split(substr($tirada['tirada'], -3)));
    $primerosTresDigitosSiguiente = array_map('intval', str_split(substr($tirada['tirada_siguiente'], 0, 3)));
    
    $paridadUltimos = implode('', array_map(function($n) { return $n % 2 ? 'I' : 'P'; }, $ultimosTresDigitos));
    $paridadSiguientes = implode('', array_map(function($n) { return $n % 2 ? 'I' : 'P'; }, $primerosTresDigitosSiguiente));
    
    $patron = $paridadUltimos . '-' . $paridadSiguientes;
    
    if (!isset($patrones['paridad'][$patron])) {
        $patrones['paridad'][$patron] = ['frecuencia' => 1, 'efectividad' => 1];
    } else {
        $patrones['paridad'][$patron]['frecuencia']++;
        $patrones['paridad'][$patron]['efectividad'] = 
            ($patrones['paridad'][$patron]['efectividad'] * ($patrones['paridad'][$patron]['frecuencia'] - 1) + 1) / 
            $patrones['paridad'][$patron]['frecuencia'];
    }
}

function analizarPatronRepeticion($tirada, &$patrones) {
    $ultimosTresDigitos = str_split(substr($tirada['tirada'], -3));
    $primerosTresDigitosSiguiente = str_split(substr($tirada['tirada_siguiente'], 0, 3));
    
    $repeticiones = array_intersect($ultimosTresDigitos, $primerosTresDigitosSiguiente);
    $cantidadRepeticiones = count($repeticiones);
    
    $patron = $cantidadRepeticiones;
    
    if (!isset($patrones['repeticion'][$patron])) {
        $patrones['repeticion'][$patron] = ['frecuencia' => 1, 'efectividad' => 1];
    } else {
        $patrones['repeticion'][$patron]['frecuencia']++;
        $patrones['repeticion'][$patron]['efectividad'] = 
            ($patrones['repeticion'][$patron]['efectividad'] * ($patrones['repeticion'][$patron]['frecuencia'] - 1) + 1) / 
            $patrones['repeticion'][$patron]['frecuencia'];
    }
}

function actualizarEstadisticasGenerales($tiradas) {
    $frecuenciaDigitos = array_fill(0, 10, 0);
    
    $frecuenciaPares = 0;
    $frecuenciaImpares = 0;
    $sumaTotal = 0;
    $totalNumeros = 0;

    foreach ($tiradas as $tirada) {
        $digitos = str_split($tirada['tirada']);
        foreach ($digitos as $digito) {
            $frecuenciaDigitos[$digito]++;
            $sumaTotal += $digito;
            $totalNumeros++;
            if ($digito % 2 == 0) {
                $frecuenciaPares++;
            } else {
                $frecuenciaImpares++;
            }
        }
    }

    for ($i = 0; $i < 10; $i++) {
        actualizarEstadistica('frecuencia_digito', $i, $frecuenciaDigitos[$i]);
    }

    actualizarEstadistica('frecuencia_pares', 'pares', $frecuenciaPares);
    actualizarEstadistica('frecuencia_impares', 'impares', $frecuenciaImpares);
    actualizarEstadistica('promedio', 'promedio', $totalNumeros > 0 ? round($sumaTotal / $totalNumeros, 2) : 0);
}

function predecirSiguienteTirada($tiradaActual) {
    $predicciones = [];
    $tiposPatrones = ['completo', 'parcial', 'suma', 'paridad', 'repeticion'];

    $mejorMetodo = obtenerMejorMetodo();
    if ($mejorMetodo && $mejorMetodo['tasa_exito'] >= 80) {
        $tiposPatrones = [$mejorMetodo['tipo']];
    }

    foreach ($tiposPatrones as $tipo) {
        $patrones = obtenerPatrones($tipo);
        $prediccionesTipo = predecirPorTipo($tipo, $tiradaActual, $patrones);
        $predicciones = array_merge($predicciones, $prediccionesTipo);
    }

    usort($predicciones, function($a, $b) {
        return $b['confianza'] - $a['confianza'];
    });

    $predicciones = array_slice($predicciones, 0, 40);

    insertarPrediccion($tiradaActual, $predicciones, $tiposPatrones[0]);

    return $predicciones;
}

function predecirPorTipo($tipo, $tiradaActual, $patrones) {
    $predicciones = [];

    switch ($tipo) {
        case 'completo':
            foreach ($patrones as $patron) {
                $partes = explode('-', $patron['patron']);
                if ($partes[0] == substr($tiradaActual, -3)) {
                    $predicciones[] = [
                        'prediccion' => $partes[1],
                        'confianza' => $patron['efectividad'] * $patron['frecuencia']
                    ];
                }
            }
            break;
        
        case 'parcial':
            $digitosUltimos = str_split(substr($tiradaActual, -3));
            $prediccionesParciales = [[], [], []];
            foreach ($patrones as $patron) {
                $partes = explode('-', $patron['patron']);
                for ($i = 0; $i < 3; $i++) {
                    if ($partes[0] == $digitosUltimos[$i]) {
                        $prediccionesParciales[$i][] = [
                            'digito' => $partes[1],
                            'confianza' => $patron['efectividad'] * $patron['frecuencia']
                        ];
                    }
                }
            }
            for ($i = 0; $i < 3; $i++) {
                usort($prediccionesParciales[$i], function($a, $b) {
                    return $b['confianza'] - $a['confianza'];
                });
                $prediccionesParciales[$i] = array_slice($prediccionesParciales[$i], 0, 3);
            }
            foreach ($prediccionesParciales[0] as $d1) {
                foreach ($prediccionesParciales[1] as $d2) {
                    foreach ($prediccionesParciales[2] as $d3) {
                        $predicciones[] = [
                            'prediccion' => $d1['digito'] . $d2['digito'] . $d3['digito'],
                            'confianza' => ($d1['confianza'] + $d2['confianza'] + $d3['confianza']) / 3
                        ];
                    }
                }
            }
            break;
        
        case 'suma':
            $sumaUltimos = array_sum(str_split(substr($tiradaActual, -3)));
            foreach ($patrones as $patron) {
                $partes = explode('-', $patron['patron']);
                if ($partes[0] == $sumaUltimos) {
                    $sumaSiguiente = $partes[1];
                    for ($i = 0; $i <= 9; $i++) {
                        for ($j = 0; $j <= 9; $j++) {
                            $k = $sumaSiguiente - $i - $j;
                            if ($k >= 0 && $k <= 9) {
                                $predicciones[] = [
                                    'prediccion' => $i . $j . $k,
                                    'confianza' => $patron['efectividad'] * $patron['frecuencia']
                                ];
                            }
                        }
                    }
                }
            }
            break;
        
        case 'paridad':
            $paridadUltimos = implode('', array_map(function($n) { return $n % 2 ? 'I' : 'P'; }, str_split(substr($tiradaActual, -3))));
            foreach ($patrones as $patron) {
                $partes = explode('-', $patron['patron']);
                if ($partes[0] == $paridadUltimos) {
                    $paridadSiguiente = str_split($partes[1]);
                    for ($i = 0; $i <= 9; $i++) {
                        for ($j = 0; $j <= 9; $j++) {
                            for ($k = 0; $k <= 9; $k++) {
                                if (($i % 2 ? 'I' : 'P') == $paridadSiguiente[0] &&
                                    ($j % 2 ? 'I' : 'P') == $paridadSiguiente[1] &&
                                    ($k % 2 ? 'I' : 'P') == $paridadSiguiente[2]) {
                                    $predicciones[] = [
                                        'prediccion' => $i . $j . $k,
                                        'confianza' => $patron['efectividad'] * $patron['frecuencia']
                                    ];
                                }
                            }
                        }
                    }
                }
            }
            break;
        
        case 'repeticion':
            $digitosUltimos = str_split(substr($tiradaActual, -3));
            foreach ($patrones as $patron) {
                $cantidadRepeticiones = $patron['patron'];
                $combinaciones = [];
                if ($cantidadRepeticiones == 0) {
                    for ($i = 0; $i <= 9; $i++) {
                        for ($j = 0; $j <= 9; $j++) {
                            for ($k = 0; $k <= 9; $k++) {
                                if ($i != $digitosUltimos[0] && $i != $digitosUltimos[1] && $i != $digitosUltimos[2] &&
                                    $j != $digitosUltimos[0] && $j != $digitosUltimos[1] && $j != $digitosUltimos[2] &&
                                    $k != $digitosUltimos[0] && $k != $digitosUltimos[1] && $k != $digitosUltimos[2]) {
                                    $combinaciones[] = $i . $j . $k;
                                }
                            }
                        }
                    }
                } elseif ($cantidadRepeticiones == 1) {
                    foreach ($digitosUltimos as $digito) {
                        for ($i = 0; $i <= 9; $i++) {
                            for ($j = 0; $j <= 9; $j++) {
                                if ($i != $digito && $j != $digito && $i != $j) {
                                    $combinaciones[] = $digito . $i . $j;
                                    $combinaciones[] = $i . $digito . $j;
                                    $combinaciones[] = $i . $j . $digito;
                                }
                            }
                        }
                    }
                } elseif ($cantidadRepeticiones == 2) {
                    for ($i = 0; $i < 3; $i++) {
                        for ($j = $i + 1; $j < 3; $j++) {
                            for ($k = 0; $k <= 9; $k++) {
                                if ($k != $digitosUltimos[$i] && $k != $digitosUltimos[$j]) {
                                    $combinacion = [$k, $k, $k];
                                    $combinacion[$i] = $digitosUltimos[$i];
                                    $combinacion[$j] = $digitosUltimos[$j];
                                    $combinaciones[] = implode('', $combinacion);
                                }
                            }
                        }
                    }
                } elseif ($cantidadRepeticiones == 3) {
                    $combinaciones[] = implode('', $digitosUltimos);
                }
                
                foreach ($combinaciones as $combinacion) {
                    $predicciones[] = [
                        'prediccion' => $combinacion,
                        'confianza' => $patron['efectividad'] * $patron['frecuencia']
                    ];
                }
            }
            break;
    }

    return $predicciones;
}

function autoevaluarSistema() {
    $tiradas = obtenerTiradas(2);
    if (count($tiradas) < 2) {
        return;
    }

    $tiradaAnterior = $tiradas[1];
    $tiradaActual = $tiradas[0];

    actualizarResultadoPrediccion($tiradaAnterior['tirada'], substr($tiradaActual['tirada'], 0, 3));

    $tasaExito = obtenerTasaExito();
    $mejorMetodo = obtenerMejorMetodo();

    if ($mejorMetodo && $mejorMetodo['tasa_exito'] >= 80) {
        $GLOBALS['mejor_metodo'] = $mejorMetodo['tipo'];
    } else {
        $GLOBALS['mejor_metodo'] = null;
    }

    return [
        'tasa_exito' => $tasaExito,
        'mejor_metodo' => $mejorMetodo
    ];
}

analizarPatrones();
?>