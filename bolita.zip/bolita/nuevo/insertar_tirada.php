<?php
require_once 'db_connection_avanzado.php';
require_once 'analisis_avanzado.php';

$success_message = "";
$error_message = "";

// Verificar si el formulario fue enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $tirada = $_POST['tirada'];
    $tirada_siguiente = $_POST['tirada_siguiente'];
    $fecha_siguiente = $_POST['fecha_siguiente'];
    $hora_siguiente = $_POST['hora_siguiente'];

    // Insertar la tirada
    insertarTirada($fecha, $hora, $tirada, $tirada_siguiente, $fecha_siguiente, $hora_siguiente);

    // Actualizar predicciones y patrones
    actualizarPrediccionesYPatrones($tirada, $tirada_siguiente);

    $success_message = "Tirada insertada correctamente y sistema actualizado.";
}

function actualizarPrediccionesYPatrones($tirada, $tirada_siguiente) {
    // Actualizar el resultado de la predicción anterior
    actualizarResultadoPrediccion($tirada, substr($tirada_siguiente, 0, 3));

    // Analizar patrones con la nueva tirada
    analizarPatrones();

    // Generar nueva predicción
    $nuevaPrediccion = predecirSiguienteTirada($tirada_siguiente);

    // Aquí podrías guardar la nueva predicción si lo deseas
    // Por ejemplo: guardarNuevaPrediccion($tirada_siguiente, $nuevaPrediccion);
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insertar Tirada y Actualizar Predicciones</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .form-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 500px;
            width: 100%;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }
        input[type="text"],
        input[type="date"],
        input[type="time"] {
            width: 100%;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #ddd;
            font-size: 14px;
            color: #333;
        }
        .btn-submit {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
        .message {
            margin-top: 15px;
            text-align: center;
            font-size: 14px;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h1>Insertar Nueva Tirada y Actualizar Predicciones</h1>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        <div class="form-group">
            <label for="fecha">Fecha</label>
            <input type="date" id="fecha" name="fecha" required>
        </div>
        <div class="form-group">
            <label for="hora">Hora</label>
            <input type="time" id="hora" name="hora" required>
        </div>
        <div class="form-group">
            <label for="tirada">Tirada</label>
            <input type="text" id="tirada" name="tirada" maxlength="7" pattern="\d{7}" required>
        </div>
        <div class="form-group">
            <label for="tirada_siguiente">Tirada Siguiente</label>
            <input type="text" id="tirada_siguiente" name="tirada_siguiente" maxlength="7" pattern="\d{7}" required>
        </div>
        <div class="form-group">
            <label for="fecha_siguiente">Fecha Siguiente</label>
            <input type="date" id="fecha_siguiente" name="fecha_siguiente" required>
        </div>
        <div class="form-group">
            <label for="hora_siguiente">Hora Siguiente</label>
            <input type="time" id="hora_siguiente" name="hora_siguiente" required>
        </div>
        <button type="submit" class="btn-submit">Insertar Tirada y Actualizar Sistema</button>

        <?php if (!empty($success_message)): ?>
            <p class="message success"><?php echo $success_message; ?></p>
        <?php endif; ?>

        <?php if (!empty($error_message)): ?>
            <p class="message error"><?php echo $error_message; ?></p>
        <?php endif; ?>
    </form>
</div>

</body>
</html>