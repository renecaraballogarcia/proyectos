<?php
require_once 'db_connection_avanzado.php';
require_once 'analisis_avanzado.php';

function obtenerDatosSistema() {
    $datos = [
        'tiradas' => obtenerUltimasTiradas(10),
        'patrones' => [
            'completo' => obtenerPatrones('completo', 10),
            'parcial' => obtenerPatrones('parcial', 10),
            'suma' => obtenerPatrones('suma', 10),
            'paridad' => obtenerPatrones('paridad', 10),
            'repeticion' => obtenerPatrones('repeticion', 10)
        ],
        'estadisticas' => [
            'frecuencia_digitos' => obtenerEstadisticas('frecuencia_digito'),
            'paridad' => [
                'pares' => obtenerEstadisticas('frecuencia_pares'),
                'impares' => obtenerEstadisticas('frecuencia_impares')
            ],
            'promedio' => obtenerEstadisticas('promedio')
        ],
        'predicciones' => obtenerUltimasPredicciones(10),
        'efectividad' => [
            'tasa_exito' => obtenerTasaExito(),
            'mejor_metodo' => obtenerMejorMetodo()
        ]
    ];

    return $datos;
}

function obtenerUltimasTiradas($limit = 10) {
    return obtenerTiradas($limit);
}

function obtenerUltimasPredicciones($limit = 10) {
    global $conn;
    $sql = "SELECT * FROM predicciones ORDER BY fecha_prediccion DESC LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $datos = obtenerDatosSistema();
    echo json_encode($datos);
} else {
    echo json_encode(['error' => 'Método de solicitud no válido']);
}
?>